<?php

namespace App\Http\Livewire\PA\Asrama;

use Livewire\Component;
use Illuminate\Support\Str;
use Livewire\WithPagination;
use App\Models\Asrama\Asrama;

class Index extends Component
{
    use WithPagination;
    protected $paginationTheme = 'bootstrap';
    public $dataId, $name, $slug, $address, $status;
    public $updateMode = false;

    public function render()
    {
        $datas = Asrama::orderBy('id')->paginate(5);

        return view('livewire.p-a.asrama.index',[
            'datas' => $datas,
        ])
            ->layout('admin.layouts.app');
    }

    public function resetInputFields()
    {
        $this->dataId = '';
        $this->name = '';
        $this->address = '';
    }

    public function cancel()
    {
        $this->updateMode = false;
        $this->resetInputFields();
    }

    public function store()
    {
        // sleep(1);
        $validasi = $this->validate([
            'name' => 'required',
            'address' => 'nullable',
            // 'file' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:15120',
        ]);

        if ($validasi) {
            $data = new Asrama;
            $data->name = $this->name;
            $data->slug = Str::slug($this->name);
            $data->address = $this->address;
            $data->status = 'Active';
            $data->save();
        }

        $this->resetInputFields();

        $this->emit('dataStore',['message' => 'Kelas berhasil ditambahkan.']);
    }

    public function edit($id)
    {
        $this->updateMode = true;
        $data = Asrama::findOrFail($id);

        $this->dataId = $data->id;
        $this->name = $data->name;
        $this->slug = $data->slug;
        $this->address = $data->address;
    }

    public function update()
    {
        sleep(1);
        $validasi = $this->validate([
            'name' => 'required',
            'address' => 'nullable',
            // 'file' => 'nullable|image|mimes:jpeg,png,jpg|max:15120',
        ]);

        if ($validasi && $this->updateMode == true) {
            $data = Asrama::findOrFail($this->dataId);
            $data->name = $this->name;
            $data->slug = Str::slug($this->name);
            $data->address = $this->address;
            $data->save();

            $this->updateMode = false;
            $this->resetInputFields();
            $this->emit('dataStore',['message' => 'Edit Kelas Berhasil!']);
        }
    }

    public function delete($id)
    {
        $data = Asrama::findOrFail($id);
        $data->delete();

        $this->emit('dataStore',['message' => 'Kelas berhasil dihapus!']);
    }
}
