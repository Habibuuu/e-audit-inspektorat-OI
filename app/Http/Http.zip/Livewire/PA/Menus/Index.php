<?php

namespace App\Http\Livewire\PA\Menus;

use Livewire\Component;
use App\Models\Util\Menus;
use Illuminate\Support\Str;
use Livewire\WithPagination;

class Index extends Component
{
    use WithPagination;
    protected $paginationTheme = 'bootstrap';
    public $dataId, $parentId, $nama, $url, $sort, $status;
    public $updateMode = false;

    public function render()
    {
        $datas = Menus::where('parent_id', '0')->orderBy('sort')->paginate(5);
        // $parents = Menus::where('parent_id', '0')->orderBy('name')->get();
        return view('livewire.p-a.menus.index', [
            'datas' => $datas,
            // 'parents' => $parents,
        ])
            ->layout('admin.layouts.app');
    }

    public function resetInputFields()
    {
        $this->dataId = '';
        $this->nama = '';
        $this->parentId = '';
        $this->url = '';
        $this->sort = '';
    }

    public function cancel()
    {
        $this->updateMode = false;
        $this->resetInputFields();
    }

    public function store()
    {
        sleep(1);
        $validasi = $this->validate([
            'nama' => 'required',
            // 'parentId' => 'required',
            'sort' => 'required | numeric | min:1',
            'url' => 'required',
        ]);

        if ($validasi) {
            $data = new Menus;
            // $data->parent_id = $this->parentId;
            $data->parent_id = 0;
            $data->sort = $this->sort;
            $data->url = $this->url;
            $data->name = $this->nama;
            $data->slug = Str::slug($this->nama);
            $data->status = "Draft";
            $data->save();

            session()->flash('success', 'Menu berhasil ditambahkan.');
            $this->resetInputFields();
            $this->emit('dataStore');
        }
    }

    public function edit($id)
    {
        $this->updateMode = true;
        $data = Menus::findOrFail($id);

        $this->dataId = $data->id;
        $this->parentId = $data->parent_id;
        $this->sort = $data->sort;
        $this->url = $data->url;
        $this->nama = $data->name;
        $this->status = $data->status;
    }

    public function update()
    {
        sleep(1);
        $validasi = $this->validate([
            'nama' => 'required',
            // 'parentId' => 'required',
            'sort' => 'required | numeric | min:1',
            'url' => 'required',
        ]);

        if ($validasi && $this->updateMode == true) {
            $data = Menus::findOrFail($this->dataId);
            // $data->parent_id = $this->parentId;
            $data->parent_id = 0;
            $data->sort = $this->sort;
            $data->url = $this->url;
            $data->name = $this->nama;
            $data->slug = Str::slug($this->nama);
            $data->save();

            $this->updateMode = false;
            session()->flash('success', 'Menu berhasil diperbarui.');
            $this->resetInputFields();
            $this->emit('dataStore');
        }
    }

    public function delete($id)
    {
        $data = Menus::findOrFail($id);
        $data->delete();

        session()->flash('success', 'Menu berhasil dihapus!');
        return redirect()->route('admin.settings-menus');
    }

    public function changeStatus($id)
    {
        $data = Menus::findOrFail($id);
        $oldStatus = $data->status;
        if ($oldStatus == 'Publish') {
            $data->status = 'Draft';
        } else {
            $data->status = 'Publish';
        }

        $data->save();

        session()->flash('success', 'Status berhasil diperbarui!');
        return redirect()->route('admin.settings-menus');
    }
}
