<?php

namespace App\Http\Livewire\PA\Videos;

use Livewire\Component;
use Illuminate\Support\Str;
use Livewire\WithPagination;
use App\Models\Posting\Videos;

class Index extends Component
{
    use WithPagination;
    protected $paginationTheme = 'bootstrap';
    public $dataId, $judul, $linkYoutube, $status;
    public $updateMode = false;

    public function render()
    {
        $datas = Videos::latest()->paginate(5);
        return view('livewire.p-a.videos.index', [
            'datas' => $datas,
        ])
            ->layout('admin.layouts.app');
    }

    public function resetInputFields()
    {
        $this->judul = '';
        $this->linkYoutube = '';
    }

    public function store()
    {
        sleep(1);
        $validasi = $this->validate([
            'judul' => 'required',
            'linkYoutube' => 'required',
        ]);
        if ($validasi) {
            $url = $this->linkYoutube;
            parse_str(parse_url($url, PHP_URL_QUERY), $youtube);
            $linkYt = $youtube['v'];

            $data = new Videos;
            $data->title = $this->judul;
            $data->slug = Str::slug($this->judul);
            $data->youtube_id = $linkYt;
            $data->status = "Draft";
            $data->save();

            session()->flash('success', 'Video berhasil ditambahkan.');

            $this->resetInputFields();

            $this->emit('dataStore');
        }
    }

    public function edit($id)
    {
        $this->updateMode = true;
        $data = Videos::findOrFail($id);

        $this->dataId = $data->id;
        $this->judul = $data->title;
        $this->slug = $data->slug;
        $this->linkYoutube = 'https://www.youtube.com/watch?v='.$data->youtube_id;
    }

    public function update()
    {
        sleep(1);
        $validasi = $this->validate([
            'judul' => 'required',
            'linkYoutube' => 'required',
        ]);
        if ($validasi && $this->updateMode == true) {
            $url = $this->linkYoutube;
            parse_str(parse_url($url, PHP_URL_QUERY), $youtube);
            $linkYt = $youtube['v'];

            $data = Videos::findOrFail($this->dataId);
            $data->title = $this->judul;
            $data->slug = Str::slug($this->judul);
            $data->youtube_id = $linkYt;
            $data->save();

            $this->updateMode = false;
            session()->flash('success', 'Video berhasil diperbarui.');
            $this->resetInputFields();
            $this->emit('dataStore');
        }
    }

    public function cancel()
    {
        $this->updateMode = false;
        $this->resetInputFields();
    }

    public function delete($id)
    {
        $data = Videos::findOrFail($id);
        $data->delete();

        session()->flash('success', 'Video berhasil dihapus!');
        return redirect()->route('admin.videos-index');
    }

    public function changeStatus($id)
    {
        $data = Videos::findOrFail($id);
        $oldStatus = $data->status;
        if ($oldStatus == 'Publish') {
            $data->status = 'Draft';
        } else {
            $data->status = 'Publish';
        }

        $data->save();

        session()->flash('success', 'Status berhasil diperbarui!');
        return redirect()->route('admin.videos-index');
    }
}
