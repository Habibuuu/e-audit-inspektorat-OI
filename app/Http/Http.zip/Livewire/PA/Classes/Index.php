<?php

namespace App\Http\Livewire\PA\Classes;

use Livewire\Component;
use Illuminate\Support\Str;
use Livewire\WithPagination;
use App\Models\Classes\Classes;

class Index extends Component
{
    use WithPagination;
    protected $paginationTheme = 'bootstrap';
    public $dataId, $name, $slug, $teacher, $teacherId, $description, $status;
    public $updateMode = false;

    public function render()
    {
        $datas = Classes::orderBy('id')->paginate(5);

        return view('livewire.p-a.classes.index',[
            'datas' => $datas,
        ])
            ->layout('admin.layouts.app');
    }

    public function resetInputFields()
    {
        $this->dataId = '';
        $this->name = '';
        $this->description = '';
    }

    public function cancel()
    {
        $this->updateMode = false;
        $this->resetInputFields();
    }

    public function store()
    {
        // sleep(1);
        $validasi = $this->validate([
            'name' => 'required',
            'description' => 'nullable',
            // 'file' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:15120',
        ]);

        if ($validasi) {
            $data = new Classes;
            $data->name = $this->name;
            $data->slug = Str::slug($this->name);
            $data->description = $this->description;
            $data->status = 'Active';
            $data->save();
        }

        $this->resetInputFields();

        $this->emit('dataStore',['message' => 'Kelas berhasil ditambahkan.']);
    }

    public function edit($id)
    {
        $this->updateMode = true;
        $data = Classes::findOrFail($id);

        $this->dataId = $data->id;
        $this->name = $data->name;
        $this->slug = $data->slug;
        $this->description = $data->description;
    }

    public function update()
    {
        sleep(1);
        $validasi = $this->validate([
            'name' => 'required',
            'description' => 'nullable',
            // 'file' => 'nullable|image|mimes:jpeg,png,jpg|max:15120',
        ]);

        if ($validasi && $this->updateMode == true) {
            $data = Classes::findOrFail($this->dataId);
            $data->name = $this->name;
            $data->slug = Str::slug($this->name);
            $data->description = $this->description;
            $data->save();

            $this->updateMode = false;
            $this->resetInputFields();
            $this->emit('dataStore',['message' => 'Edit Kelas Berhasil!']);
        }
    }

    public function delete($id)
    {
        $data = Classes::findOrFail($id);
        $data->delete();

        $this->emit('dataStore',['message' => 'Kelas berhasil dihapus!']);
    }
}
