<?php

namespace App\Http\Livewire\PA\DataJabatan;

use Livewire\Component;
use Illuminate\Support\Str;
use Livewire\WithPagination;
use App\Models\Data\DataJabatan;

class Index extends Component
{
    use WithPagination;
    protected $paginationTheme = 'bootstrap';
    public $dataId, $name, $slug, $ranking, $status;
    public $updateMode = false;

    public function render()
    {
        $datas = DataJabatan::orderBy('tier')->paginate(5);

        return view('livewire.p-a.data-jabatan.index',[
            'datas' => $datas,
        ])
            ->layout('admin.layouts.app');
    }

    public function resetInputFields()
    {
        $this->dataId = '';
        $this->name = '';
        $this->ranking = '';
    }

    public function cancel()
    {
        $this->updateMode = false;
        $this->resetInputFields();
    }

    public function store()
    {
        // sleep(1);
        $validasi = $this->validate([
            'name' => 'required',
            'ranking' => 'required|numeric|min:1',
            // 'file' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:15120',
        ]);

        if ($validasi) {
            $data = new DataJabatan;
            $data->name = $this->name;
            $data->slug = Str::slug($this->name);
            $data->tier = $this->ranking;
            $data->status = 'Active';
            $data->save();
        }

        $this->resetInputFields();

        $this->emit('dataStore',['message' => 'Jabatan berhasil ditambahkan.']);
    }

    public function edit($id)
    {
        $this->updateMode = true;
        $data = DataJabatan::findOrFail($id);

        $this->dataId = $data->id;
        $this->name = $data->name;
        $this->ranking = $data->tier;
        $this->slug = $data->slug;
        $this->status = $data->status;
    }

    public function update()
    {
        sleep(1);
        $validasi = $this->validate([
            'name' => 'required',
            'ranking' => 'required|numeric|min:1',
            // 'file' => 'nullable|image|mimes:jpeg,png,jpg|max:15120',
        ]);

        if ($validasi && $this->updateMode == true) {
            $data = DataJabatan::findOrFail($this->dataId);
            $data->name = $this->name;
            $data->slug = Str::slug($this->name);
            $data->tier = $this->ranking;
            $data->save();

            $this->updateMode = false;
            $this->resetInputFields();
            $this->emit('dataStore',['message' => 'Edit Jabatan Berhasil!']);
        }
    }

    public function delete($id)
    {
        $data = DataJabatan::findOrFail($id);
        $data->delete();

        $this->emit('dataStore',['message' => 'Jabatan berhasil dihapus!']);
    }
}
