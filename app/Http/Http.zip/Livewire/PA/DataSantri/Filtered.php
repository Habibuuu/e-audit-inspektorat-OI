<?php

namespace App\Http\Livewire\PA\DataSantri;

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Asrama\Asrama;
use App\Models\Data\DataSiswa;
use App\Models\Classes\Classes;
use App\Models\Data\DataKategori;
use Illuminate\Support\Facades\Request;

class Filtered extends Component
{
    use WithPagination;
    protected $paginationTheme = 'bootstrap';
    public $nama_lengkap;
    public $updateMode = false;

    public function mount()
    {
        $this->nama_lengkap;
        dd($this->nama_lengkap);
        $this->datas = DataSiswa::where('nama_lengkap', 'like', '%' . $this->nama_lengkap . '%')
            ->latest()
            ->paginate(10);
    }

    public function render()
    {
        $datas = DataSiswa::latest()->paginate(10);
        $arrType = DataKategori::where('type', 'Santri')->orderBy('name')->get();
        $arrKelas = Classes::orderBy('name')->get();
        $arrAsrama = Asrama::orderBy('name')->get();

        return view('livewire.p-a.data-santri.index', [
            'datas' => $datas,
            'arrType' => $arrType,
            'arrKelas' => $arrKelas,
            'arrAsrama' => $arrAsrama,
        ])
            ->layout('admin.layouts.app');
    }

    public function delete($id)
    {
        $data = DataSiswa::findOrFail($id);
        $data->delete();

        $this->emit('dataStore', ['message' => 'Data berhasil dihapus!']);
    }

}
