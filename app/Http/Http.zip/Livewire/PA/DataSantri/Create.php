<?php

namespace App\Http\Livewire\PA\DataSantri;

use Livewire\Component;
use Illuminate\Support\Str;
use App\Models\Regions\Desa;
use App\Models\Asrama\Asrama;
use Livewire\WithFileUploads;
use App\Models\Data\DataSiswa;
use App\Models\Classes\Classes;
use App\Models\Data\DataStatus;
use App\Models\Data\DataJabatan;
use App\Models\Regions\Provinsi;
use App\Models\Data\DataKategori;
use App\Models\Regions\Kabupaten;
use App\Models\Regions\Kecamatan;
use Intervention\Image\Facades\Image;

class Create extends Component
{
    use WithFileUploads;
    public $dataId, $namaLengkap, $kategori, $photo, $tempatLahir, $tanggalLahir, $kelas, $kelasId, $asrama, $asramaId, $status_santri, $alamat, $regionId, $provId, $kabId, $kecId, $kelId, $telpon, $telponOrtu, $namaAyah, $namaIbu, $email, $jenisKelamin, $tahunMasuk, $tahunLulus, $statusPendidikan, $informasi_tambahan, $status_yatim, $status;
    public $arrKab = [];
    public $arrKec = [];
    public $arrKel = [];

    public function render()
    {
        $types = DataKategori::where('type', 'Santri')->orderBy('id')->get();
        $ranks = DataStatus::orderBy('name')->get();
        $provices = Provinsi::orderBy('nama')->get();
        $arrKelas = Classes::orderBy('name')->get();
        $arrAsrama = Asrama::orderBy('name')->get();

        return view('livewire.p-a.data-santri.create', [
            'types' => $types,
            'ranks' => $ranks,
            'provices' => $provices,
            'arrKelas' => $arrKelas,
            'arrAsrama' => $arrAsrama,
        ])
            ->layout('admin.layouts.app');
    }

    public function showKab()
    {
        $this->kabId = '';
        $this->kecId = '';
        $this->kelId = '';
        $this->arrKab = Kabupaten::where('provinsi_id', $this->provId)->orderBy('nama')->get();
    }

    public function showKec()
    {
        $this->kecId = '';
        $this->kelId = '';
        $this->arrKec = Kecamatan::where('kabupaten_id', $this->kabId)->orderBy('nama')->get();
    }

    public function showKel()
    {
        $this->kelId = '';
        $this->arrKel = Desa::where('kecamatan_id', $this->kecId)->orderBy('nama')->get();
    }


    public function store()
    {
        sleep(1);
        $validasi = $this->validate([
            'namaLengkap' => 'required',
            'kategori' => 'required',
            // 'jabatan' => 'required',
            'tempatLahir' => 'required',
            'tanggalLahir' => 'required',
            'kelas' => 'nullable',
            'asrama' => 'nullable',
            'provId' => 'required',
            'kabId' => 'nullable|required_with:provId',
            'kecId' => 'nullable|required_with:kabId',
            'kelId' => 'nullable|required_with:kecId',
            'telpon' => 'nullable|numeric',
            'telponOrtu' => 'nullable|numeric',
            'tahunMasuk' => 'nullable|numeric',
            'tahunLulus' => 'nullable|numeric',
            'email' => 'nullable|email',
            'photo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:51200',
        ]);

        if ($validasi) {

            $fn = explode(' ', $this->namaLengkap, 2);
            $firstName = $fn[0];
            $lastName = '';
            if (isset($fn[1])) {
                $lastName = $fn[1];
            }

            $data = new DataSiswa;
            $data->type = 'Santri';
            $data->nama_lengkap = $this->namaLengkap;
            $data->nama_depan = $firstName;
            $data->nama_belakang = $lastName;
            $data->tempat_lahir = $this->tempatLahir;
            $data->tanggal_lahir = $this->tanggalLahir;
            $data->kelas_id = $this->kelas;
            $data->asrama_id = $this->asrama;
            $data->alamat = $this->alamat ?? "";
            $data->asal_prov_id = $this->provId;
            $data->asal_kab_id = $this->kabId;
            $data->asal_kec_id = $this->kecId;
            $data->asal_kel_id = $this->kelId;
            $data->kelamin = $this->jenisKelamin ?? "";
            $data->telpon = $this->telpon ?? "";
            $data->nama_ayah = $this->namaAyah ?? "";
            $data->nama_ibu = $this->namaIbu ?? "";
            $data->telpon_wali = $this->telponOrtu ?? "";
            $data->email = $this->email ?? "";
            $data->tahun_diterima = $this->tahunMasuk ?? "";
            $data->tahun_lulus = $this->tahunLulus ?? "";
            $data->status_yatim = $this->status_yatim ?? "";
            $data->status = 'Active';
            $data->informasi_tambahan = $this->informasi_tambahan ?? "";

            if ($this->photo) {
                $photo = $this->photo;
                $imageName = Str::slug($this->namaLengkap) . '.' . $photo->getClientOriginalExtension();

                // ORIGINAL
                $destinationPath = public_path('/storage/persons/original/');
                $img = Image::make($photo->getRealPath());
                $QuploadImage = $img->resize(1080, 1080, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . $imageName, 100);

                // SMALL
                $destinationPath = public_path('/storage/persons/small/');
                $img = Image::make($photo->getRealPath());
                $QuploadImage = $img->resize(480, 480, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . $imageName, 100);

                $data->photo = $imageName;
            }
            $data->save();

            if ($data) {
                // Kategori
                $kategoriNames = $this->kategori;
                $kategoriIds = [];

                foreach ($kategoriNames as $kategoriName) {
                    $kategori = DataKategori::firstOrCreate([
                        'type' => 'Santri',
                        'name' => $kategoriName,
                        'slug' => Str::slug($kategoriName),
                    ]);

                    if ($kategori) {
                        $kategoriIds[] = [
                            'kategori_id' =>$kategori->id,
                            'type' => 'Santri'
                        ];
                    }
                }
                $data->Kategori()->sync($kategoriIds);

                // Status Santri
                $statusNames = $this->status_santri;
                $statusIds = [];

                foreach ($statusNames as $statusName) {
                    $status = DataStatus::firstOrCreate([
                        'name' => $statusName,
                        'slug' => Str::slug($statusName),
                    ]);

                    if ($status) {
                        $statusIds[] = $status->id;
                    }
                }
                $data->Status()->sync($statusIds);

            }

            $this->emit('dataStore', ['message' => 'Data Berhasil ditambahkan!']);
            return redirect()->route('admin.santri-index');
        }
    }
}
