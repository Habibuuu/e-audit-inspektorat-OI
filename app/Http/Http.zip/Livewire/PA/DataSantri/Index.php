<?php

namespace App\Http\Livewire\PA\DataSantri;

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Asrama\Asrama;
use App\Models\Data\DataSiswa;
use App\Models\Classes\Classes;
use App\Models\Data\DataKategori;

class Index extends Component
{
    use WithPagination;
    protected $paginationTheme = 'bootstrap';
    public $nama_lengkap, $asrama, $kelas, $kategori;
    public $updateMode = false;
    protected $listeners = ['filter'];

    public function mount()
    {
        $this->datas = DataSiswa::where('type','Santri')->latest()->paginate(10);
    }

    public function render()
    {
        $arrType = DataKategori::where('type', 'Santri')->orderBy('name')->get();
        $arrKelas = Classes::orderBy('name')->get();
        $arrAsrama = Asrama::orderBy('name')->get();

        return view('livewire.p-a.data-santri.index', [
            'datas' => $this->datas,
            'arrType' => $arrType,
            'arrKelas' => $arrKelas,
            'arrAsrama' => $arrAsrama,
        ])
            ->layout('admin.layouts.app');
    }

    public function delete($id)
    {
        $data = DataSiswa::findOrFail($id);
        $data->delete();

        $this->datas = DataSiswa::where('type','Santri')->latest()->paginate(10);
        $this->emit('dataStore', ['message' => 'Data berhasil dihapus!']);
    }

    public function filter()
    {
        $filtered = DataSiswa::where('type','Santri')->latest();

        if($this->nama_lengkap){
            $filtered = $filtered->where('nama_lengkap', 'like', '%' . $this->nama_lengkap . '%');
        }

        if($this->kategori){
            $kategoriId = $this->kategori;
            $filtered = $filtered->whereHas('getKategori', function($q) use ($kategoriId){
                $q->where('kategori_id', $kategoriId);
            });
        }

        if($this->kelas){
            $kelasId = $this->kelas;
            $filtered = $filtered->whereHas('Kelas', function($q) use ($kelasId){
                $q->where('id', $kelasId);
            });
        }

        if($this->asrama){
            $asramaId = $this->asrama;
            $filtered = $filtered->whereHas('Asrama', function($q) use ($asramaId){
                $q->where('id', $asramaId);
            });
        }

        $this->datas = $filtered->paginate(10);
    }

    public function resetInputFields()
    {
        $this->nama_lengkap = "";
        $this->kategori = "";
        $this->kelas = "";
        $this->asrama = "";
        $this->datas = DataSiswa::where('type','Santri')->latest()->paginate(10);
    }
}
