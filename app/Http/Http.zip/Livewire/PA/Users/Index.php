<?php

namespace App\Http\Livewire\PA\Users;

use App\Models\User;
use Livewire\Component;
use Livewire\WithPagination;

class Index extends Component
{
    use WithPagination;
    protected $paginationTheme = 'bootstrap';

    public function render()
    {
        $datas = User::where('id','>','1')->latest()->paginate(5);

        return view('livewire.p-a.users.index',[
            'datas' => $datas,
        ])->layout('admin.layouts.app');
    }

    public function delete($id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        session()->flash('success', 'User berhasil dihapus!');
        return redirect()->route('admin.users-index');
    }
}
