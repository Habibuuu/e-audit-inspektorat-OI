<?php

namespace App\Http\Livewire\PA\DataStaff;

use Livewire\Component;
use Illuminate\Support\Str;
use App\Models\Regions\Desa;
use Livewire\WithFileUploads;
use App\Models\Data\DataSiswa;
use App\Models\Data\DataStaff;
use App\Models\Data\DataJabatan;
use App\Models\Regions\Provinsi;
use App\Models\Data\DataKategori;
use App\Models\Regions\Kabupaten;
use App\Models\Regions\Kecamatan;
use Intervention\Image\Facades\Image;

class Create extends Component
{
    use WithFileUploads;
    public $dataId, $namaLengkap, $kategori, $photo, $tempatLahir, $tanggalLahir, $jabatan, $alamat, $provId, $kabId, $kecId, $kelId, $telpon, $email, $jenisKelamin,  $informasi_tambahan, $status;
    public $arrKab = [];
    public $arrKec = [];
    public $arrKel = [];

    public function render()
    {
        $types = DataKategori::where('type', 'SDM')->orderBy('id')->get();
        $ranks = DataJabatan::orderBy('name')->get();
        $provices = Provinsi::orderBy('nama')->get();

        return view('livewire.p-a.data-staff.create', [
            'types' => $types,
            'ranks' => $ranks,
            'provices' => $provices,
        ])
            ->layout('admin.layouts.app');
    }

    public function showKab()
    {
        $this->kabId = '';
        $this->kecId = '';
        $this->kelId = '';
        $this->arrKab = Kabupaten::where('provinsi_id', $this->provId)->orderBy('nama')->get();
    }

    public function showKec()
    {
        $this->kecId = '';
        $this->kelId = '';
        $this->arrKec = Kecamatan::where('kabupaten_id', $this->kabId)->orderBy('nama')->get();
    }

    public function showKel()
    {
        $this->kelId = '';
        $this->arrKel = Desa::where('kecamatan_id', $this->kecId)->orderBy('nama')->get();
    }

    public function store()
    {
        sleep(1);
        $validasi = $this->validate([
            'namaLengkap' => 'required',
            'kategori' => 'required',
            'tempatLahir' => 'required',
            'tanggalLahir' => 'required',
            'provId' => 'required',
            'kabId' => 'nullable|required_with:provId',
            'kecId' => 'nullable|required_with:kabId',
            'kelId' => 'nullable|required_with:kecId',
            'telpon' => 'nullable|numeric',
            'email' => 'nullable|email',
            'photo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:51200',
        ]);

        if ($validasi) {

            $fn = explode(' ', $this->namaLengkap, 2);
            $firstName = $fn[0];
            $lastName = '';
            if (isset($fn[1])) {
                $lastName = $fn[1];
            }

            $data = new DataSiswa;
            $data->type = 'SDM';
            $data->nama_lengkap = $this->namaLengkap;
            $data->nama_depan = $firstName;
            $data->nama_belakang = $lastName;
            $data->tempat_lahir = $this->tempatLahir;
            $data->tanggal_lahir = $this->tanggalLahir;
            $data->alamat = $this->alamat ?? "";
            $data->asal_prov_id = $this->provId;
            $data->asal_kab_id = $this->kabId;
            $data->asal_kec_id = $this->kecId;
            $data->asal_kel_id = $this->kelId;
            $data->kelamin = $this->jenisKelamin ?? "";
            $data->telpon = $this->telpon ?? "";
            $data->email = $this->email ?? "";
            $data->status = 'Active';
            $data->informasi_tambahan = $this->informasi_tambahan ?? "";

            if ($this->photo) {
                $photo = $this->photo;
                $imageName = Str::slug($this->namaLengkap) . '.' . $photo->getClientOriginalExtension();

                // ORIGINAL
                $destinationPath = public_path('/storage/persons/original/');
                $img = Image::make($photo->getRealPath());
                $QuploadImage = $img->resize(1080, 1080, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . $imageName, 100);

                // SMALL
                $destinationPath = public_path('/storage/persons/small/');
                $img = Image::make($photo->getRealPath());
                $QuploadImage = $img->resize(480, 480, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . $imageName, 100);

                $data->photo = $imageName;
            }
            $data->save();

            if ($data) {
                // Kategori
                $kategoriNames = $this->kategori;
                $kategoriIds = [];

                foreach ($kategoriNames as $kategoriName) {
                    $kategori = DataKategori::firstOrCreate([
                        'type' => 'SDM',
                        'name' => $kategoriName,
                        'slug' => Str::slug($kategoriName),
                    ]);

                    if ($kategori) {
                        $kategoriIds[] = [
                            'kategori_id' =>$kategori->id,
                            'type' => 'SDM'
                        ];
                    }
                }
                $data->Kategori()->sync($kategoriIds);

                // Jabatan
                $jabatanNames = $this->jabatan;
                $jabatanIds = [];

                foreach ($jabatanNames as $jabatanName) {
                    $jabatan = DataJabatan::firstOrCreate([
                        'name' => $jabatanName,
                        'slug' => Str::slug($jabatanName),
                    ]);

                    if ($jabatan) {
                        $jabatanIds[] = $jabatan->id;
                    }
                }
                $data->Jabatan()->sync($jabatanIds);

            }

            $this->emit('dataStore', ['message' => 'Data SDM Berhasil ditambahkan!']);
            return redirect()->route('admin.sdm-index');
        }
    }
}
