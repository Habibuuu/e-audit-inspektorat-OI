<?php

namespace App\Http\Livewire\PA\Banners;

use Livewire\Component;
use Illuminate\Support\Str;
use App\Models\Util\Banners;
use Livewire\WithPagination;
use Livewire\WithFileUploads;
use Intervention\Image\Facades\Image;

class Index extends Component
{
    use WithPagination;
    use WithFileUploads;
    protected $paginationTheme = 'bootstrap';
    public $dataId, $judul, $caption, $file, $fileGet, $status;
    public $updateMode = false;

    public function render()
    {
        $datas = Banners::latest()->paginate(5);
        return view('livewire.p-a.banners.index', [
            'datas' => $datas,
        ])
            ->layout('admin.layouts.app');
    }

    public function resetInputFields()
    {
        $this->dataId = '';
        $this->judul = '';
        $this->caption = '';
        $this->file = '';
    }

    public function store()
    {
        sleep(1);
        $validasi = $this->validate([
            'judul' => 'required',
            'caption' => 'nullable',
            'file' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:15120',
        ]);

        if ($validasi) {
            $data = new Banners;
            $data->title = $this->judul;
            $data->slug = Str::slug($this->judul);
            $data->caption = $this->caption;
            $data->status = 'Draft';
            if ($this->file) {
                $file = $this->file;
                $fileName = $data->slug . '.' . $file->getClientOriginalExtension();

                // ORIGINAL
                $destinationPath = public_path('/storage/banners/');
                $img = Image::make($file->getRealPath());
                $QuploadImage = $img->resize(1080, 1080, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . $fileName, 100);

                $data->filename = $fileName;
            }
            $data->save();
        }

        session()->flash('success', 'Banner berhasil ditambahkan.');

        $this->resetInputFields();

        $this->emit('dataStore');
    }

    public function edit($id)
    {
        $this->updateMode = true;
        $data = Banners::findOrFail($id);

        $this->dataId = $data->id;
        $this->judul = $data->title;
        $this->slug = $data->slug;
        $this->caption = $data->caption;
        $this->fileGet = $data->filename;
        $this->status = $data->status;
    }

    public function update()
    {
        sleep(1);
        $validasi = $this->validate([
            'judul' => 'required',
            'file' => 'nullable|image|mimes:jpeg,png,jpg|max:15120',
        ]);

        if ($validasi && $this->updateMode == true) {
            $data = Banners::findOrFail($this->dataId);
            $data->title = $this->judul;
            $data->slug = Str::slug($this->judul);
            $data->caption = $this->caption;

            if ($this->file) {
                $file = $this->file;
                $fileName = $data->slug . '.' . $file->getClientOriginalExtension();

                // ORIGINAL
                $destinationPath = public_path('/storage/banners/');
                $img = Image::make($file->getRealPath());
                $QuploadImage = $img->resize(1080, 1080, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . $fileName, 100);

                $data->filename = $fileName;
            }

            $data->save();

            $this->updateMode = false;
            session()->flash('success', 'Infografis berhasil diperbarui.');
            $this->resetInputFields();
            $this->emit('dataStore');
        }
    }

    public function cancel()
    {
        $this->updateMode = false;
        $this->resetInputFields();
    }

    public function delete($id)
    {
        $data = Banners::findOrFail($id);
        $data->delete();

        session()->flash('success', 'Banner berhasil dihapus!');
        return redirect()->route('admin.settings-banners');
    }

    public function changeStatus($id)
    {
        $data = Banners::findOrFail($id);
        $oldStatus = $data->status;
        if ($oldStatus == 'Publish') {
            $data->status = 'Draft';
        } else {
            $data->status = 'Publish';
        }

        $data->save();

        session()->flash('success', 'Status berhasil diperbarui!');
        return redirect()->route('admin.settings-banners');
    }
}
