<?php

namespace App\Http\Livewire\PA\Articles;

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Articles\Article;

class Index extends Component
{
    use WithPagination;
    protected $paginationTheme = 'bootstrap';

    public function render()
    {
        $datas = Article::latest()->paginate(5);

        return view('livewire.p-a.articles.index',[
            'datas' => $datas,
        ])->layout('admin.layouts.app');
    }

    public function delete($id)
    {
        $data = Article::findOrFail($id);
        $data->delete();

        session()->flash('success', 'Artikel berhasil dihapus!');
        return redirect()->route('admin.articles-index');
    }

    public function changeStatus($id)
    {
        $data = Article::findOrFail($id);
        $oldStatus = $data->status;
        $autoPublishCheck = $data->is_auto_publish;
        if($autoPublishCheck == 1 && $oldStatus == 'Publish')
        {
            $data->status = 'Draft';
            $data->is_auto_publish = 0;
            $data->published_at = null;
        }elseif($autoPublishCheck == 0 && $oldStatus == 'Publish')
        {
            $data->status = 'Draft';
        }elseif($autoPublishCheck == 0 && $oldStatus == 'Draft')
        {
            $data->status = 'Publish';
        }
        $data->save();

        session()->flash('success', 'Status berhasil diperbarui!');
        return redirect()->route('admin.articles-index');
    }
}
