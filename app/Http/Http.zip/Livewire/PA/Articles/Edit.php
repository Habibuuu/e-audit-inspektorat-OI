<?php

namespace App\Http\Livewire\PA\Articles;

use Livewire\Component;
use Illuminate\Support\Str;
use Livewire\WithFileUploads;
use App\Models\Articles\Article;
use App\Models\Articles\ArticleTags;
use App\Models\Articles\ArticleType;
use Intervention\Image\Facades\Image;

class Edit extends Component
{

    use WithFileUploads;
    public $articleId;
    public $judul_artikel;
    public $deskripsi;
    public $isi_artikel;
    public $rekomendasi;
    public $status;
    public $jenisId;
    public $nama_jenis;
    public $tagsId = [];
    public $tags;
    public $thumbnail;
    public $thumbnailGet;
    public $autoPublish;
    public $tanggal_publish;

    public function mount($id)
    {
        $data = Article::findOrFail($id);
        if ($data) {
            $this->articleId = $data->id;
            $this->judul_artikel = $data->title;
            $this->deskripsi = $data->description;
            $this->isi_artikel = $data->content;
            $this->rekomendasi = $data->is_recommend;
            $this->jenisId = $data->type_id;
            $this->nama_jenis = $data->Type->name;
            $this->tags = $data->getTags;
            // foreach($data->getTags as $getTag){
            //     $this->tagsId = $getTag->name;
            // }
            $this->tagsId = [];
            foreach($data->getTags as $tag){
                $this->tagsId[] = $tag->name;
            }
            $this->thumbnailGet = $data->thumbnail;
            $this->autoPublish = $data->is_auto_publish;
            $this->tanggal_publish = $data->published_at;
        }
    }

    public function render()
    {
        $types = ArticleType::orderBy('name')->get();
        $arrTags = ArticleTags::orderBy('name')->get();
        return view('livewire.p-a.articles.edit',[
            'types' => $types,
            'arrTags' => $arrTags,
        ])
        ->layout('admin.layouts.app');
    }

    public function update()
    {
        sleep(1);
        $data = Article::findOrFail($this->articleId);
        // dd($this->autoPublish);

        $validasi = $this->validate([
            'judul_artikel' => 'required|min:5',
            'deskripsi' => 'required',
            'isi_artikel' => 'required',
            'rekomendasi' => 'required',
            'jenisId' => 'required',
            'tagsId' => 'required',
            'autoPublish' => 'required',
            'tanggal_publish' => 'nullable|date|required_if:autoPublish,1',
            'thumbnail' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:5120',
        ]);

        if ($validasi) {
            if($this->autoPublish == 0)
            {
                $autoPub = 0;
                $this->tanggal_publish = null;
            }elseif($this->autoPublish == 1)
            {
                $autoPub = 1;
                $data->status = 'Publish';
            }

            // DOM UPLOAD IMAGE ON SUMMERNOTE
            $domIsiArtikel = $this->deskripsi;
            $dom = new \DomDocument();
            $dom->loadHtml($domIsiArtikel, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
            $domImage = $dom->getElementsByTagName('img');

            foreach($domImage as $k => $img){
                $domData = $img->getAttribute('src');
                list($type, $domData) = explode(';', $domData);
                list($type, $domData) = explode(',', $domData);
                $domData = base64_decode($domData);
                $image_name= "/storage/images/" . time().$k.'.png';
                // $path = public_path() . $image_name;
                $path = public_path($image_name);
                file_put_contents($path, $domData);
                $img->removeAttribute('src');
                $img->setAttribute('src', $image_name);
             }
             $domIsiArtikel = $dom->saveHTML();
            // DOM UPLOAD IMAGE ON SUMMERNOTE

            $data->title = $this->judul_artikel;
            $data->type_id = $this->jenisId;
            $data->description = $this->deskripsi;
            $data->content = $this->isi_artikel;
            $data->is_recommend = $this->rekomendasi;
            $data->is_auto_publish = $autoPub;
            $data->published_at = $this->tanggal_publish;
            if ($this->thumbnail) {
                if ($this->thumbnail) {
                    $photo = $this->thumbnail;
                    $imageName = Str::slug($this->judul_artikel) . '.' . $photo->getClientOriginalExtension();

                    // ORIGINAL
                    $destinationPath = public_path('/storage/images/thumbnail/original/');
                    $img = Image::make($photo->getRealPath());
                    $QuploadImage = $img->resize(1080, 1080, function ($constraint) {
                        $constraint->aspectRatio();
                    })->save($destinationPath . $imageName, 100);

                    // SMALL
                    $destinationPath = public_path('/storage/images/thumbnail/small/');
                    $img = Image::make($photo->getRealPath());
                    $QuploadImage = $img->resize(480, 480, function ($constraint) {
                        $constraint->aspectRatio();
                    })->save($destinationPath . $imageName, 100);

                    $data->thumbnail = $imageName;
                }
            }
            $data->save();

            if ($data) {
                $tagNames = $this->tagsId;
                $tagIds = [];

                foreach ($tagNames as $tagName) {
                    $tag = ArticleTags::firstOrCreate([
                        'name' => $tagName,
                        'slug' => Str::slug($tagName),
                    ]);

                    if ($tag) {
                        $tagIds[] = $tag->id;
                    }
                }
                $data->Tags()->sync($tagIds);
            }

            session()->flash('success', 'Artikel berhasil diperbarui!');
            return redirect()->route('admin.articles-index');
        }
    }
}
