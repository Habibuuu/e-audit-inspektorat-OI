<?php

namespace App\Http\Livewire\PA\DataKategori;

use Livewire\Component;
use Illuminate\Support\Str;
use Livewire\WithPagination;
use App\Models\Data\DataKategori;

class Index extends Component
{
    use WithPagination;
    protected $paginationTheme = 'bootstrap';
    public $dataId, $name, $slug, $tipe, $status;
    public $updateMode = false;

    public function render()
    {
        $datas = DataKategori::orderBy('type')->orderBy('name')->paginate(5);

        return view('livewire.p-a.data-kategori.index',[
            'datas' => $datas,
        ])
            ->layout('admin.layouts.app');
    }

    public function resetInputFields()
    {
        $this->dataId = '';
        $this->name = '';
        $this->tipe = '';
    }

    public function cancel()
    {
        $this->updateMode = false;
        $this->resetInputFields();
    }

    public function store()
    {
        // sleep(1);
        $validasi = $this->validate([
            'name' => 'required',
            'tipe' => 'required',
            // 'file' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:15120',
        ]);

        if ($validasi) {
            $data = new DataKategori;
            $data->name = $this->name;
            $data->slug = Str::slug($this->name);
            $data->type = $this->tipe;
            $data->status = 'Active';
            $data->save();
        }

        $this->resetInputFields();

        $this->emit('dataStore',['message' => 'Kategori Data berhasil ditambahkan.']);
    }

    public function edit($id)
    {
        $this->updateMode = true;
        $data = DataKategori::findOrFail($id);

        $this->dataId = $data->id;
        $this->name = $data->name;
        $this->slug = $data->slug;
        $this->tipe = $data->type;
        $this->status = $data->status;
    }

    public function update()
    {
        sleep(1);
        $validasi = $this->validate([
            'name' => 'required',
            'tipe' => 'required',
            // 'file' => 'nullable|image|mimes:jpeg,png,jpg|max:15120',
        ]);

        if ($validasi && $this->updateMode == true) {
            $data = DataKategori::findOrFail($this->dataId);
            $data->name = $this->name;
            $data->slug = Str::slug($this->name);
            $data->type = $this->tipe;
            $data->save();

            $this->updateMode = false;
            $this->resetInputFields();
            $this->emit('dataStore',['message' => 'Edit Kategori Data Berhasil!']);
        }
    }

    public function delete($id)
    {
        $data = DataKategori::findOrFail($id);
        $data->delete();

        $this->emit('dataStore',['message' => 'Kategori Data berhasil dihapus!']);
    }
}
