<?php

namespace App\Http\Livewire\PA\DataStatus;

use Livewire\Component;
use Illuminate\Support\Str;
use Livewire\WithPagination;
use App\Models\Data\DataStatus;

class Index extends Component
{
    use WithPagination;
    protected $paginationTheme = 'bootstrap';
    public $dataId, $name, $slug, $ranking, $status;
    public $updateMode = false;

    public function render()
    {
        $datas = DataStatus::orderBy('id')->paginate(5);
        return view('livewire.p-a.data-status.index',[
            'datas' => $datas,
        ])
            ->layout('admin.layouts.app');
    }

    public function resetInputFields()
    {
        $this->dataId = '';
        $this->name = '';
        $this->ranking = '';
    }

    public function cancel()
    {
        $this->updateMode = false;
        $this->resetInputFields();
    }

    public function store()
    {
        // sleep(1);
        $validasi = $this->validate([
            'name' => 'required',
        ]);

        if ($validasi) {
            $data = new DataStatus;
            $data->name = $this->name;
            $data->slug = Str::slug($this->name);
            $data->status = 'Active';
            $data->save();
        }

        $this->resetInputFields();

        $this->emit('dataStore',['message' => 'Status Santri berhasil ditambahkan.']);
    }

    public function edit($id)
    {
        $this->updateMode = true;
        $data = DataStatus::findOrFail($id);

        $this->dataId = $data->id;
        $this->name = $data->name;
        $this->ranking = $data->tier;
        $this->slug = $data->slug;
        $this->status = $data->status;
    }

    public function update()
    {
        sleep(1);
        $validasi = $this->validate([
            'name' => 'required',
        ]);

        if ($validasi && $this->updateMode == true) {
            $data = DataStatus::findOrFail($this->dataId);
            $data->name = $this->name;
            $data->slug = Str::slug($this->name);
            $data->save();

            $this->updateMode = false;
            $this->resetInputFields();
            $this->emit('dataStore',['message' => 'Edit Status Santri Berhasil!']);
        }
    }

    public function delete($id)
    {
        $data = DataStatus::findOrFail($id);
        $data->delete();

        $this->emit('dataStore',['message' => 'Status Santri berhasil dihapus!']);
    }
}
