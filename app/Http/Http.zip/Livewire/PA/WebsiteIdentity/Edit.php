<?php

namespace App\Http\Livewire\PA\WebsiteIdentity;

use App\Models\Settings\WebsIdentity;
use Livewire\Component;
use Livewire\WithFileUploads;
use Intervention\Image\Facades\Image;

class Edit extends Component
{
    use WithFileUploads;
    public $dataId, $nama_website, $deskripsi, $getLogo, $getFav, $logo, $favicon, $email, $alamat, $googlemap, $telpon, $facebook, $instagram, $youtube, $twitter;

    public function mount()
    {
        $data = WebsIdentity::find(1);
        // dd($data);
        if($data)
        {
            $this->dataId = $data->id;
            $this->nama_website = $data->name;
            $this->deskripsi = $data->description;
            $this->getLogo = $data->logo;
            $this->getFav = $data->favicon;
            $this->email = $data->email;
            $this->alamat = $data->address;
            $this->googlemap = $data->googlemap;
            $this->telpon = $data->telephone;
            $this->facebook = $data->facebook;
            $this->instagram = $data->instagram;
            $this->youtube = $data->youtube;
            $this->twitter = $data->twitter;
        }
    }

    public function render()
    {
        return view('livewire.p-a.website-identity.edit')
        ->layout('admin.layouts.app');
    }

    public function update()
    {
        sleep(1);
        $data = WebsIdentity::findOrFail(1);
        $validasi = $this->validate([
            'nama_website' => 'required|min:5',
            'deskripsi' => 'required',
            'email' => 'required|email',
            'alamat' => 'required',
            'googlemap' => 'required',
            'telpon' => 'required',
            'facebook' => 'required',
            'instagram' => 'required',
            'youtube' => 'required',
            'twitter' => 'required',
            'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:5120',
            'favicon' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:5120',
        ]);

        if($validasi)
        {
            $data->name = $this->nama_website;
            $data->description = $this->deskripsi;
            $data->address = $this->alamat;
            $data->googlemap = $this->googlemap;
            $data->telephone = $this->telpon;
            $data->facebook = $this->facebook;
            $data->instagram = $this->instagram;
            $data->youtube = $this->youtube;
            $data->twitter = $this->twitter;
            if($this->logo)
            {
                $photo = $this->logo;
                $imageName = 'logo-ori.' . $photo->getClientOriginalExtension();
                $imageNameSmall = 'logo-small.' . $photo->getClientOriginalExtension();

                // ORIGINAL
                $destinationPath = public_path('/images/');
                $img = Image::make($photo->getRealPath());
                $QuploadImage = $img->resize(1080, 1080, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . $imageName, 100);

                // SMALL
                $destinationPath = public_path('/images/');
                $img = Image::make($photo->getRealPath());
                $QuploadImage = $img->resize(480, 480, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . $imageNameSmall, 100);

                $data->logo = $imageName;
            }
            if($this->favicon)
            {
                $photo = $this->favicon;
                $imageName = 'favicon-ori.' . $photo->getClientOriginalExtension();
                $imageNameSmall = 'favicon-small.' . $photo->getClientOriginalExtension();

                // ORIGINAL
                $destinationPath = public_path('/images/');
                $img = Image::make($photo->getRealPath());
                $QuploadImage = $img->resize(1080, 1080, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . $imageName, 100);

                // SMALL
                $destinationPath = public_path('/images/');
                $img = Image::make($photo->getRealPath());
                $QuploadImage = $img->resize(480, 480, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . $imageNameSmall, 100);

                $data->favicon = $imageName;
            }

            $data->save();

            session()->flash('success', 'Informasi Website diperbarui!');
            return redirect()->route('admin.settings-website-identity');
        }

    }
}
