<?php

namespace App\Http\Livewire\PA;

use Carbon\Carbon;
use Livewire\Component;
use App\Models\Visitors;
use Illuminate\Support\Facades\DB;

class Dashboard extends Component
{
    public function render()
    {
        $pnjngValue = Visitors::where('datetime', '>', Carbon::now()->subMonth(1))
        ->groupBy('date')
        ->select('visit', DB::raw('count(*) as visit'))
        ->get();

        $pnjngDate= Visitors::where('datetime', '>', Carbon::now()->subMonth(1))
        ->groupBy('date')
        ->get();

        $pnjngURL = Visitors::where('datetime', '>', Carbon::now()->subMonth(1))
        ->select(['visit', DB::raw('count(*) as visit'),'url'])
        ->groupBy('url')
        ->orderByDesc('visit')
        ->get();

        $pnjngURLHighest = Visitors::where('datetime', '>', Carbon::now()->subMonth(1))
        ->select(['visit', DB::raw('count(*) as visit'),'url'])
        ->groupBy('url')
        ->orderByDesc('visit')
        ->first();

        return view('livewire.p-a.dashboard',[
            'pnjngValue' => $pnjngValue,
            'pnjngDate' => $pnjngDate,
            'pnjngURL' => $pnjngURL,
            'pnjngURLHighest' => $pnjngURLHighest,
        ])
        ->layout('admin.layouts.app');
    }
}
